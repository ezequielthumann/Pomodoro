import Main from "./src/views/main";
import Principal from "./src/views/main";

export default function App() {
  return <Main />;
}
